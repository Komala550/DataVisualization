import vtk

# Define color transfer function
color_transfer_function = vtk.vtkColorTransferFunction()
color_transfer_function.AddRGBPoint(-4931.54, 0, 1, 1)
color_transfer_function.AddRGBPoint(-2508.95, 0, 0, 1)
color_transfer_function.AddRGBPoint(-1873.9, 0, 0, 0.5)
color_transfer_function.AddRGBPoint(-1027.16, 1, 0, 0)
color_transfer_function.AddRGBPoint(-298.031, 1, 0.4, 0)
color_transfer_function.AddRGBPoint(2594.97, 1, 1, 0)

# Define opacity transfer function
opacity_transfer_function = vtk.vtkPiecewiseFunction()
opacity_transfer_function.AddPoint(-4931.54, 1.0)
opacity_transfer_function.AddPoint(101.815, 0.002)
opacity_transfer_function.AddPoint(2594.97, 0.0)

# Load 3D data 
reader = vtk.vtkXMLImageDataReader()
reader.SetFileName('Isabel_3D.vti')
reader.Update()

# Create volume property
volume_property = vtk.vtkVolumeProperty()
volume_property.SetColor(color_transfer_function)
volume_property.SetScalarOpacity(opacity_transfer_function)

use_phong_shading = input("Do you want to use Phong shading? (yes/no): ").lower() == 'yes'

# Enable Phong shading if requested
if use_phong_shading:
    volume_property.ShadeOn()
    # Set Phong shading parameters
    volume_property.SetAmbient(0.5)
    volume_property.SetDiffuse(0.5)
    volume_property.SetSpecular(0.5)
    

# Create volume mapper
volume_mapper = vtk.vtkSmartVolumeMapper()
volume_mapper.SetInputConnection(reader.GetOutputPort())

# Create volume
volume = vtk.vtkVolume()
volume.SetMapper(volume_mapper)
volume.SetProperty(volume_property)

# Create outline filter
outline_filter = vtk.vtkOutlineFilter()
outline_filter.SetInputConnection(reader.GetOutputPort())

# Create outline mapper
outline_mapper = vtk.vtkPolyDataMapper()
outline_mapper.SetInputConnection(outline_filter.GetOutputPort())

# Create outline actor
outline_actor = vtk.vtkActor()
outline_actor.SetMapper(outline_mapper)
outline_actor.GetProperty().SetColor(0, 0, 0)

# Create renderer
renderer = vtk.vtkRenderer()
renderer.AddVolume(volume)
renderer.AddActor(outline_actor)
renderer.SetBackground(1, 1, 1)

# Create render window
render_window = vtk.vtkRenderWindow()
render_window.AddRenderer(renderer)
render_window.SetSize(1000, 1000)

# Create render window interactor
interactor = vtk.vtkRenderWindowInteractor()
interactor.SetRenderWindow(render_window)

# Start rendering
render_window.Render()
interactor.Start()
