####The data files should be in same dictionary as python script files
# Problem1

## Description
This Python script uses the VTK library to find isocontours in a 2D dataset. It reads a VTK image data file (`Isabel_2D.vti`), extracts the pressure values from the dataset, and generates isocontour lines based on a specified threshold value.

## Installation
To run this script, you need to have VTK installed. You can install VTK using pip:

```bash
pip install vtk

## Usage
Run the script with the desired threshold value as a command-line argument.

python isocontour.py 200

## Options
threshold: The threshold value for isocontour generation. Default is 0 if not specified.

## Credits
https://chat.openai.com,Sir lectures

##The data output will be in outputpolydata.vtp
Load it in Paraview to see output

#Problem2

# VTK Volume Rendering

## Description
This Python script uses VTK to perform volume rendering of 3D data. It reads a VTK image data file (`Isabel_3D.vti`), defines color and opacity transfer functions, and creates a volume with specified properties. The script also allows the user to enable Phong shading for the volume.

## Installation
To run this script, you need to have VTK installed. You can install VTK using pip:

```bash
pip install vtk

python volume_rendering.py 200

## Options
use_phong_shading: Set to 'yes' to enable Phong shading, or 'no' to disable. Default is 'no'.

## Credits
https://chat.openai.com,Sir lectures



