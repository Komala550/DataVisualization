import sys
import vtk
import numpy as np
cells = vtk.vtkCellArray()
vtk_points = vtk.vtkPoints()
lookup_table = [
    [],
    [[0,1],[2,0]],
    [[1,3],[0,1]],
    [[0,2],[1,3]],
    [[2,3],[1,3]],
    [[0,2],[2,3],[0,1],[1,3]],
    [[2,3],[0,1]],
    [[2,0],[2,3]],
    [[0,2],[2,3]],
    [[2,3],[0,1]],
    [[0,2],[0,1],[1,3],[3,2]],
    [[2,3],[3,1]],
    [[0,2],[1,3]],
    [[0,1],[1,3]],
    [[2,0],[0,1]],
    [],
]
def findIsoContour(data,numberOfCells,threshold,dataArrPreassure):
    for i in range(numberOfCells):
        cell = data.GetCell(i)
        pid1 = cell.GetPointId(0)
        pid2 = cell.GetPointId(1)
        pid3 = cell.GetPointId(3)
        pid4 = cell.GetPointId(2)
        pid=[pid1,pid2,pid3,pid4]
        values=[]
        for e in pid:
            values.append(dataArrPreassure.GetTuple1(e))
        bits=[]
        for val in values:
            bits.append(1 if val >= threshold else 0)
        
        case = (bits[3] << 3) | (bits[2] << 2) | (bits[1] << 1) | bits[0]
        if case not in [0,15,5,10]:
            edge_vertex_ids = lookup_table[case]
            points = []
            pressures = []
            for edge in edge_vertex_ids:
                for vpid in edge:
                    point = data.GetPoint(cell.GetPointId(vpid))
                    pressure = dataArrPreassure.GetTuple1(cell.GetPointId(vpid))
                    points.append(point)
                    pressures.append(pressure)
            point1, point2, point3, point4 = points[:4]
            pre1, pre2, pre3, pre4 = pressures[:4]
            if abs(pre1 - pre2) < 1e-10:
                t1 = 0.5
            else:
                t1 = (threshold - pre1)/(pre2 - pre1)
            
            x1 = point1[0]+(t1*(point2[0]-point1[0]))
            y1 = point1[1]+(t1*(point2[1]-point1[1]))
            z1 = point1[2]+(t1*(point2[2]-point1[2]))
        
            if abs(pre3 - pre4) < 1e-10:
                t2 = 0.5
            else:
                t2 = (threshold - pre3)/(pre4 - pre3)
            
            x2 = point3[0]+(t2*(point4[0]-point3[0]))
            y2 = point3[1]+(t2*(point4[1]-point3[1]))
            z2 = point3[2]+(t2*(point4[2]-point3[2]))
        
            p1 = (x1,y1,z1)
            p2 = (x2,y2,z2)
        
            id1 = vtk_points.InsertNextPoint(p1)
            id2 = vtk_points.InsertNextPoint(p2)
            line = vtk.vtkLine()
            line.GetPointIds().SetId(0, id1)
            line.GetPointIds().SetId(1, id2)
            cells.InsertNextCell(line)
        
        elif case in [5, 10]:
            for edge in edge_vertex_ids:
                points = []
                pressures = []
                for vpid in edge:
                    point = data.GetPoint(cell.GetPointId(vpid))
                    pressure = dataArrPreassure.GetTuple1(cell.GetPointId(vpid))
                    points.append(point)
                    pressures.append(pressure)
            ts = []
            for i in range(len(points) // 2):
                pre1, pre2 = pressures[i * 2], pressures[i * 2 + 1]
                if abs(pre1 - pre2) < 1e-10:
                    ts.append(0.5)
                else:
                    t = (threshold - pre1) / (pre2 - pre1)
                    ts.append(t)

                # Interpolate points
            interpolated_points = []
            for i in range(len(points) // 2):
                point1, point2 = points[i * 2], points[i * 2 + 1]
                t = ts[i]
                x = point1[0] + (t * (point2[0] - point1[0]))
                y = point1[1] + (t * (point2[1] - point1[1]))
                z = point1[2] + (t * (point2[2] - point1[2]))
                interpolated_points.append((x, y, z))

        # Insert points into vtkPoints
            ids = []
            for p in interpolated_points:
                id = vtk_points.InsertNextPoint(p)
                ids.append(id)

        # Create a new vtkLine object and set its point ids
            line = vtk.vtkLine()
            line.GetPointIds().SetNumberOfIds(len(ids))
            for i, id in enumerate(ids):
                line.GetPointIds().SetId(i, id)

        # Add the line to the vtkCellArray
            cells.InsertNextCell(line)

        else:
            empty_cell = vtk.vtkIdList()
            cells.InsertNextCell(empty_cell)
if __name__ == "__main__":
    reader = vtk.vtkXMLImageDataReader()
    reader.SetFileName('Isabel_2D.vti')
    reader.Update()
    data   = reader.GetOutput()
    numberOfCells = data.GetNumberOfCells()
    if len(sys.argv) > 1:
        threshold = int(sys.argv[1])
        print("Entered threshold value is : ",threshold)
    else:
        threshold = 0
        print("No iso value is specidied,Taking default iso value 200")
    dataArrPreassure = data.GetPointData().GetArray('Pressure')
    findIsoContour(data,numberOfCells,threshold,dataArrPreassure)
    # Create a vtkPolyData object from the points
    polydata = vtk.vtkPolyData()
    polydata.SetPoints(vtk_points)

    # Add the lines to the polydata object
    polydata.SetLines(cells)

    # write data to output
    writer = vtk.vtkXMLPolyDataWriter()
    writer.SetFileName('outputpolydata.vtp')
    writer.SetInputData(polydata)
    writer.Write()

    

   
