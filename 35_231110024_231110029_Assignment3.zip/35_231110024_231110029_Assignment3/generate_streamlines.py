import vtk

# Function to get the vector at a point in the dataset
def get_vector_at_point(point, dataset):
    # Create a vtkProbeFilter object to query the dataset
    probe_filter = vtk.vtkProbeFilter()
    probe_filter.SetSourceData(dataset)
    
    # Create a vtkPoints object and insert the point
    points = vtk.vtkPoints()
    points.InsertNextPoint(point)
    
    # Create a vtkPolyData object and set its points
    polydata = vtk.vtkPolyData()
    polydata.SetPoints(points)
    
    # Set the input of the probe filter
    probe_filter.SetInputData(polydata)
    
    # Update the probe filter to get the vector at the point
    probe_filter.Update()
    
    # Get the queried vector
    queried_vector = probe_filter.GetOutput().GetPointData().GetVectors().GetTuple(0)
    
    return queried_vector

# Function to perform Runge-Kutta 4 (RK4) integration
def rk4_integration(current_position, step_size, data):
    # Get the vector at the current position
    vector_at_current_position = get_vector_at_point(current_position, data)
    
    # Calculate intermediate steps k1, k2, k3, and k4
    k1 = [x for x in vector_at_current_position]
    k2 = get_vector_at_point([(x + y * (step_size/ 2)) for x, y in zip(current_position, k1)], data)
    k3 = get_vector_at_point([(x + y * (step_size/ 2)) for x, y in zip(current_position, k2)], data)
    k4 = get_vector_at_point([(x + y * (step_size)) for x, y in zip(current_position, k3)], data)
    
    # Update the position using the weighted sum of the intermediate steps
    new_position = [x + (k1[i] + 2*k2[i] + 2*k3[i] + k4[i]) * (step_size / 6) for i, x in enumerate(current_position)]
    
    return new_position

# Function to check if a point is within the dataset bounds
def contains_point(point, bounds):
    for i in range(len(point)):
        if bounds[2*i] <= point[i] <= bounds[2*i+1]:
            continue
        else:
            return False
    return True

# Function to trace the streamline in both directions from a seed location
def trace_streamline(seed_location, step_size, max_steps, data):
    streamline_points = vtk.vtkPoints()
    streamline_cells = vtk.vtkCellArray()

    current_point = seed_location
    flist = []
    for _ in range(max_steps):
        new_point = rk4_integration(current_point, step_size, data)
        if not contains_point(new_point, data.GetBounds()):
            break
        flist.append(new_point)
        current_point = new_point

    blist = []
    current_point = seed_location
    for _ in range(max_steps):
        new_point = rk4_integration(current_point, -step_size, data)
        if not contains_point(new_point, data.GetBounds()):
            break
        blist.append(new_point)
        current_point = new_point

    flist.reverse()
    for point in flist:
        streamline_points.InsertNextPoint(point)
    streamline_points.InsertNextPoint(seed_location)
    for point in blist:
        streamline_points.InsertNextPoint(point)

    for i in range(1, streamline_points.GetNumberOfPoints()):
        line = vtk.vtkLine()
        line.GetPointIds().SetId(0, i - 1)
        line.GetPointIds().SetId(1, i)
        streamline_cells.InsertNextCell(line)

    streamline = vtk.vtkPolyData()
    streamline.SetPoints(streamline_points)
    streamline.SetLines(streamline_cells)

    return streamline

# Function to create a render window for visualizing the streamline
def create_render_window(streamline_file):
    reader = vtk.vtkXMLPolyDataReader()
    reader.SetFileName(streamline_file)
    reader.Update()
    mapper = vtk.vtkPolyDataMapper()
    mapper.SetInputConnection(reader.GetOutputPort())
    actor = vtk.vtkActor()
    actor.SetMapper(mapper)
    renderer = vtk.vtkRenderer()
    renderer.AddActor(actor)
    render_window = vtk.vtkRenderWindow()
    render_window.AddRenderer(renderer)
    render_window_interactor = vtk.vtkRenderWindowInteractor()
    render_window_interactor.SetRenderWindow(render_window)
    render_window.Render()
    render_window_interactor.Start()

if __name__ == "__main__":
    # Load vector field data set
    reader = vtk.vtkXMLImageDataReader()
    reader.SetFileName("tornado3d_vector.vti")
    reader.Update()
    data = reader.GetOutput()

    # Input seed location
    seed_x = float(input("Enter x-coordinate for seed location: "))
    seed_y = float(input("Enter y-coordinate for seed location: "))
    seed_z = float(input("Enter z-coordinate for seed location: "))
    seed_location = (seed_x, seed_y, seed_z)

    # RK4 integration parameters
    step_size = 0.05
    max_steps = 10000

    streamline = trace_streamline(seed_location, step_size, max_steps, data)

    # Write the streamline to a file
    writer = vtk.vtkXMLPolyDataWriter()
    writer.SetFileName("streamline.vtp")
    writer.SetInputData(streamline)
    writer.Write()

    # Create and render the streamline
    create_render_window("streamline.vtp")

