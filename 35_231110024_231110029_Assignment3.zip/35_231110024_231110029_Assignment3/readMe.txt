Description
-----------
This Python script uses the Runge-Kutta 4 (RK4) integration method to generate streamlines from a 3D vector field dataset. It traces streamlines in both directions from a seed location and visualizes them using VTK (Visualization Toolkit).

Dependencies
--------------
VTK (Visualization Toolkit)

Usage
------
Place the script file (generate_streamlines.py) and the 3D vector field dataset (tornado3d_vector.vti) in the same directory.

Install VTK using pip install vtk.

Run the program in the command propt in the same directory using python generate_streamlines.py

Enter the x, y, and z coordinates for the seed location when prompted.

The program will trace streamlines from the seed location and create a visualization.

The output streamline will be saved in streamline.vtp.

Input limitations
------------------
Make sure to input x,y,z values with in data bounds -10 to 9.999992


Credits
-------
https://chat.openai.com,Sir lectures
